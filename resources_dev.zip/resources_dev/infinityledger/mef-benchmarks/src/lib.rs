// Benchmarks crate for MEF
// This crate exists solely to hold benchmarks
