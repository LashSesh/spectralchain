// MEF-CLI Library
// This crate provides a command-line interface for MEF-Core
// The main binary is in src/main.rs
